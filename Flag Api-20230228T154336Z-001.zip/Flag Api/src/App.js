import React from "react";
import "./App.css";
import Table from "./Table";

function App() {

  return (
    <div className="d-flex flex-column align-items-center">
      <h1>React Datatable</h1>
      <Table/>
    </div>
  );
}

export default App;
