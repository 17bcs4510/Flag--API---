import axios from "axios";
import { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import "./App.css";
function Table() {
  const [value, setValue] = useState([]);
  const [search, setSearch] = useState();
  const [filter, setFilter] = useState([]);
  const getUserData = async () => {
    try {
      const res = await axios.get("https://restcountries.com/v2/all");
      setValue(res.data);
      setFilter(res.data);
      alert('data fetched successfully')
    } catch (error) {
      console.log(error);
    }
  };
  const columns = [
    {
      name: "Name",
      selector: (row) => row.name,
      sortable: true,
    },
    {
      name: "Native Name",
      selector: (row) => row.nativeName,
      sortable: true,
    },
    {
      name: "Capital",
      selector: (row) => row.capital,
      sortable: true,
    },
    {
      name: "Action",
      cell: (row) => (
        <button
          onClick={() => alert(row.alpha2Code)}
          className="btn btn-primary btn-sm"
        >
          ID
        </button>
      ),
    },
  ];
  useEffect(() => {
    getUserData();
  }, []);

  useEffect(() => {
    const result = value.filter((bhavish) => {
      return bhavish.name.toLowerCase().match(search.toLowerCase());
    });
    setFilter(result);
  }, [search]);
  return (
    <>
      <button className="btn btn-warning btn-sm" onClick={getUserData}>
        GET USER
      </button>
      <br />
      <DataTable
        columns={columns}
        data={filter}
        pagination
        fixedHeader
        fixedHeaderScrollHeight="450px"
        highlightOnHover
        actions={<button className="btn btn-info btn-sm">export</button>}
        subHeader
        subHeaderComponent={
          <input
            className="w-25 form-control "
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search Here..."
          />
        }
      />
    </>
  );
}

export default Table;
